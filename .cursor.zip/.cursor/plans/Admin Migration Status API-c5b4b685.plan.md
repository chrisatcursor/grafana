<!-- c5b4b685-b346-41da-bc09-6db839d8b67f -->
# Admin API: Unified Storage Migration Status Endpoint

## Current State

- **Migration status logic**: Fully implemented in [pkg/storage/unified/migrations/status.go](pkg/storage/unified/migrations/status.go). `MigrationStatusReporter` and `GetStatus(ctx)` return `StatusSummary` with per-resource status, totals (completed/failed/pending), and config flags.
- **Tests**: [pkg/api/admin_unified_storage_test.go](pkg/api/admin_unified_storage_test.go) already defines expected behavior:
  - 200 with JSON when reporter exists and `GetStatus` succeeds
  - 503 when reporter is nil
  - 500 when `GetStatus` returns an error
- **Gap**: Route, handler, Wire DI, and HTTPServer field are missing. Tests inject `hs.migrationStatusReporter` via `SetupAPITestServer` but the field does not exist on `HTTPServer`.

## Implementation Plan

### 1. Add MigrationStatusReporter Wire Provider

Add `ProvideMigrationStatusReporter` in [pkg/storage/unified/migrations/status.go](pkg/storage/unified/migrations/status.go) (or a new `wire.go` in that package) that returns `*MigrationStatusReporter` from `cfg`, `sqlStore`, and `registry`. All three are already available in the Wire graph.

### 2. Extend HTTPServer and ProvideHTTPServer

In [pkg/api/http_server.go](pkg/api/http_server.go):

- Add field: `migrationStatusReporter *migrations.MigrationStatusReporter` (pointer allows nil for optional behavior; tests expect 503 when nil).
- Add parameter to `ProvideHTTPServer` and assign it in the struct initializer.

### 3. Implement Admin Handler

In [pkg/api/admin.go](pkg/api/admin.go):

- Add `AdminGetMigrationStatus(c *contextmodel.ReqContext) response.Response`:
  - If `hs.migrationStatusReporter == nil` → `response.Error(503, "Migration status not available", nil)`
  - Call `reporter.GetStatus(c.Req.Context())`; on error → `response.Error(500, "Failed to get migration status", err)`
  - On success → `response.JSON(200, summary)`
- Add swagger annotations following existing admin handlers (e.g. `AdminGetStats`).

### 4. Register Route

In [pkg/api/api.go](pkg/api/api.go), inside the `/api/admin` group (around line 549):

```go
adminRoute.Get("/unified-storage/migration-status", authorize(ac.EvalPermission(ac.ActionServerStatsRead)), routing.Wrap(hs.AdminGetMigrationStatus))
```

Uses `ActionServerStatsRead` (same as `/api/admin/stats`) per the tests.

### 5. Wire DI Updates

In [pkg/server/wire.go](pkg/server/wire.go):

- Add `unifiedmigrations.ProvideMigrationStatusReporter` to `wireBasicSet` (or create a small provider in server package that wraps `NewMigrationStatusReporter`).
- Add `migrationStatusReporter` to the `ProvideHTTPServer` parameter list in the Wire set.

Run `make gen-go` to regenerate [pkg/server/wire_gen.go](pkg/server/wire_gen.go).

### 6. Swagger Response Type (Optional)

If needed for OpenAPI, add a response type in [pkg/api/swagger_responses.go](pkg/api/swagger_responses.go) or in `admin.go` for `adminGetMigrationStatusResponse` using `migrations.StatusSummary`.

---

## Data Flow

```mermaid
flowchart LR
    Client[Client] -->|GET /api/admin/unified-storage/migration-status| Route[api.go Route]
    Route -->|reqSignedIn + ActionServerStatsRead| Handler[AdminGetMigrationStatus]
    Handler --> Reporter[MigrationStatusReporter]
    Reporter -->|GetStatus| DB[(unifiedstorage_migration_log)]
    Reporter --> Registry[MigrationRegistry]
    Reporter --> Cfg[setting.Cfg]
    Handler -->|200 JSON| Client
```

---

## Subagent Delegation

| Subagent | Task |
|----------|------|
| **api-designer** | Review the new `GET /api/admin/unified-storage/migration-status` endpoint design (auth, response shape, error codes). |
| **test-writer** | Add any additional tests beyond the existing three (e.g. permission denial, malformed responses). |
| **security-scanner** | Audit the endpoint for auth and data exposure (admin-only, no user input). |
| **docs-updater** | Update API docs or README if the endpoint is documented. |

---

## Verification

- `go test ./pkg/api/... -run TestAdminGetMigrationStatus` — existing tests should pass.
- `make gen-go` — Wire compiles without errors.
- Manual: `curl -u admin:admin http://localhost:3000/api/admin/unified-storage/migration-status` returns JSON status.
