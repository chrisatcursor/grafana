<!-- b73d0ac6-bb1d-4548-9935-35410ce88233 -->
# JWT Auth Module Refactor - Completion Plan

## Current State

**Already implemented:**
- [`pkg/services/auth/sessionjwt/service.go`](pkg/services/auth/sessionjwt/service.go) - SessionJWTService with `SignSessionToken` and `VerifySessionToken` using signingkeys (ES256)
- [`pkg/services/auth/sessionjwt/provider.go`](pkg/services/auth/sessionjwt/provider.go) - Provider for DI
- `useJWTSessions` feature flag in [`pkg/services/featuremgmt/registry.go`](pkg/services/featuremgmt/registry.go) (experimental, off by default)

**Architecture overview:**

```mermaid
flowchart TB
    subgraph current [Current Opaque Flow]
        Login1[Login] --> CreateToken1[CreateToken]
        CreateToken1 --> DB1[(user_auth_token)]
        CreateToken1 --> Cookie1[Set Cookie]
        Req1[Request] --> Cookie1
        Cookie1 --> Lookup1[LookupToken]
        Lookup1 --> DB1
    end
    
    subgraph jwt [JWT Flow - To Implement]
        Login2[Login] --> SignJWT[SignSessionToken]
        SignJWT --> DB2[(user_auth_token)]
        SignJWT --> Cookie2[Set Cookie with JWT]
        Req2[Request] --> Cookie2
        Cookie2 --> VerifyJWT[VerifySessionToken]
        VerifyJWT --> DB2
    end
```

## Implementation Plan

### 1. Integrate SessionJWT into UserAuthTokenService

**File:** [`pkg/services/auth/authimpl/auth_token.go`](pkg/services/auth/authimpl/auth_token.go)

- Add optional `*sessionjwt.Service` field to `UserAuthTokenService` struct
- Update `ProvideUserAuthTokenService` to accept `*sessionjwt.Service` parameter (can be nil for backward compat)
- **CreateToken** (when `useJWTSessions` flag is on and sessionJWT != nil):
  - Call `sessionJWT.SignSessionToken(ctx, userID, authModule, 0)` 
  - Insert into `user_auth_token` with `auth_token = hashedJTI` (not hash of opaque token), `prev_auth_token = hashedJTI`, `auth_token_seen = true` (JWT has no rotation)
  - Set `rotated_at = now + LoginMaxLifetime` so `NeedsRotation` returns false
  - Handle `ExternalSession` - still create external session and set `external_session_id` on the row
  - Return `UserToken` with `UnhashedToken = jwtString`
- **LookupToken** (when token looks like JWT - 3 dot-separated parts - and sessionJWT != nil):
  - Call `sessionJWT.VerifySessionToken(ctx, token)` to get userID and jti
  - Lookup in DB by `auth_token = sessionjwt.HashJTI(jti)` 
  - Check `revoked_at`, `created_at`, `rotated_at` as today
  - Build `UserToken` with `UnhashedToken = token`, `AuthTokenSeen = true`, `RotatedAt` from DB
  - Skip the opaque-token rotation/seen logic (lines 185-233)
- **RevokeToken**: No change - works by token Id from DB row

### 2. Wire Dependency Injection

**File:** [`pkg/server/wire.go`](pkg/server/wire.go) or [`pkg/server/wireexts_oss.go`](pkg/server/wireexts_oss.go)

- Add `sessionjwt.ProvideService` to wire set (requires `*setting.Cfg` and `signingkeys.Service` - both already available)
- Update `authimpl.ProvideUserAuthTokenService` call to pass `*sessionjwt.Service` as new parameter

**File:** [`pkg/services/auth/authimpl/auth_token.go`](pkg/services/auth/authimpl/auth_token.go)

- Add `sessionJWT *sessionjwt.Service` parameter to `ProvideUserAuthTokenService`
- Store in struct; use nil check before JWT code paths

### 3. Handle Session Cookie and Rotation for JWT

**File:** [`pkg/services/authn/authn.go`](pkg/services/authn/authn.go) - `WriteSessionCookie`

- No change needed: already uses `token.UnhashedToken` (will be JWT string)
- `token.NextRotation()` - for JWT tokens we set `RotatedAt` to expiry, so this returns correct time for `sessionExpiryCookie`

**File:** [`pkg/services/authn/clients/session.go`](pkg/services/authn/clients/session.go)

- No change: `NeedsRotation` will return false for JWT tokens (we set `AuthTokenSeen=true`, `RotatedAt` far future)

### 4. OAuth and External Sessions

When `CreateToken` is called with `ExternalSession` (OAuth login):

- Create external session in DB first (existing logic)
- For JWT: pass `externalSession.ID` to `SignSessionToken` (already in signature - use it)
- Store `external_session_id` in the `user_auth_token` row
- OAuth token sync in [`pkg/services/authn/authnimpl/sync/oauth_token_sync.go`](pkg/services/authn/authnimpl/sync/oauth_token_sync.go) uses `id.SessionToken.ExternalSessionId` - will work since we populate it

### 5. Token Rotation Endpoint

**File:** [`pkg/api/login.go`](pkg/api/login.go) or rotate handler

- When `ErrTokenNeedsRotation` triggers redirect to `/user/auth-tokens/rotate`
- For JWT: `NeedsRotation` will never be true, so no change needed
- If user has old opaque token and JWT is enabled: LookupToken will try JWT first, fail (not JWT format), then fall through - but we only have one code path. Need to ensure: **opaque tokens are still looked up when token is not JWT format** (no 3 dots). The existing LookupToken logic handles opaque; we add JWT branch at the start.

### 6. Backward Compatibility

- When `useJWTSessions` is **off**: Use existing opaque token flow (no sessionJWT calls)
- When **on**: New logins get JWT; existing sessions with opaque tokens continue to work (LookupToken: if not JWT format, use existing hashed lookup)
- Migration: Users with old cookies get opaque lookup; new logins get JWT. No forced re-login.

### 7. Fix SessionJWT SignSessionToken for External Session

**File:** [`pkg/services/auth/sessionjwt/service.go`](pkg/services/auth/sessionjwt/service.go)

- `SignSessionToken` currently has `externalSessionID int64` but does not use it in claims
- Optional: add `external_session_id` to SessionClaims for debugging; not required for lookup (we have DB row)

### 8. Error Mapping

Map `sessionjwt.ErrTokenExpired` to `auth.TokenExpiredError` in LookupToken when using JWT path.

### 9. Tests

- **sessionjwt**: Add unit tests for `SignSessionToken`, `VerifySessionToken`, `IsJWTFormat`, `HashJTI`
- **authimpl**: Add test cases for CreateToken/LookupToken with JWT enabled (mock sessionjwt, enable flag)
- **session client**: Test that JWT tokens authenticate correctly (integration-style with fake sessionjwt)

### 10. Run Code Generation

- `make gen-go` - Regenerate wire after adding sessionjwt to provider
- `make lint-go` - Fix any lint issues

## Files to Modify

| File | Changes |
|------|---------|
| `pkg/services/auth/authimpl/auth_token.go` | Add sessionJWT dep, JWT branches in CreateToken/LookupToken |
| `pkg/server/wire.go` or `wireexts_oss.go` | Add sessionjwt.ProvideService, pass to authimpl |
| `pkg/services/auth/sessionjwt/service.go` | Map ErrTokenExpired to auth errors if needed |
| `pkg/services/auth/sessionjwt/service_test.go` | New file - unit tests |

## Risk / Edge Cases

- **Key rotation**: Signingkeys rotates monthly. Old JWTs signed with previous key remain valid (key kept 30 days). Session JWTs are short-lived (LoginMaxLifetime), so low risk.
- **Logout**: RevokeToken looks up by token - for JWT we need the DB row. The UserToken from LookupToken has Id; Logout passes that. RevokeToken uses token.Id to find the row - works.
- **Concurrent sessions**: Quota/counting uses `ActiveTokenCount` - counts DB rows. JWT tokens create rows, so no change.
